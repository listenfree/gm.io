nohup pproxy &
nohup ./frpc -c frpc.ini >/dev/null 2>&1 &
